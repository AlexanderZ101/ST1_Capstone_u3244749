import tensorflow as tf
from keras.models import load_model
from PIL import Image, ImageTk, ImageOps
import numpy as np
import tkinter as tk
import os

project_folder = os.path.dirname(os.path.abspath(__file__))
# Create a GUI class
class Capstone_GUI:
    def chili_classification(self):
        # Disable scientific notation for clarity
        np.set_printoptions(suppress=True)

        # Load the model
        model = load_model("keras_Model.h5", compile=False)

        # Load the labels
        class_names = open("labels.txt", "r").readlines()

        # Create the array of the right shape to feed into the keras model
        data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)

        # Replace this with the path to your image (escape backslashes)
        image_path = os.path.join(project_folder, "chili_test.jpg")
        image = Image.open(image_path).convert("RGB")

        # resizing the image to be at least 224x224 and then cropping from the center
        size = (224, 224)
        image = ImageOps.fit(image, size, Image.LANCZOS)

        # turn the image into a numpy array
        image_array = np.asarray(image)

        # Normalize the image
        normalized_image_array = (image_array.astype(np.float32) / 127.5) - 1

        # Load the image into the array
        data[0] = normalized_image_array

        # Predicts the model
        prediction = model.predict(data)
        index = np.argmax(prediction)
        class_name = class_names[index]
        confidence_score = prediction[0][index]

        # Display the class and confidence score
        self.class_label.config(text=f'Class: {class_name[2:]}')
        self.confidence_label.config(text=f'Confidence Score: {confidence_score}')

        # Display the image
        img = Image.open("chili_test.jpg")
        img = img.resize((128, 128), Image.LANCZOS)
        image = ImageTk.PhotoImage(img)
        self.imageLabel.configure(image=image)
        self.imageLabel.image = image

    def lemon_classification(self):
        # Disable scientific notation for clarity
        np.set_printoptions(suppress=True)

        # Load the model
        model = load_model("keras_Model.h5", compile=False)

        # Load the labels
        class_names = open("labels.txt", "r").readlines()

        # Create the array of the right shape to feed into the keras model
        data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)

        # Replace this with the path to your image (escape backslashes)
        image_path = os.path.join(project_folder, "0010_0014.JPG")
        image = Image.open(image_path).convert("RGB")

        # resizing the image to be at least 224x224 and then cropping from the center
        size = (224, 224)
        image = ImageOps.fit(image, size, Image.LANCZOS)

        # turn the image into a numpy array
        image_array = np.asarray(image)

        # Normalize the image
        normalized_image_array = (image_array.astype(np.float32) / 127.5) - 1

        # Load the image into the array
        data[0] = normalized_image_array

        # Predicts the model
        prediction = model.predict(data)
        index = np.argmax(prediction)
        class_name = class_names[index]
        confidence_score = prediction[0][index]

        # Display the class and confidence score
        self.class_label.config(text=f'Class: {class_name[2:]}')
        self.confidence_label.config(text=f'Confidence Score: {confidence_score}')

        # Display the image
        img = Image.open("0010_0014.JPG")
        img = img.resize((128, 128), Image.LANCZOS)
        image = ImageTk.PhotoImage(img)
        self.imageLabel.configure(image=image)
        self.imageLabel.image = image

    def coffee_classification(self):
        # Disable scientific notation for clarity
        np.set_printoptions(suppress=True)

        # Load the model
        model = load_model("keras_Model.h5", compile=False)

        # Load the labels
        class_names = open("labels.txt", "r").readlines()

        # Create the array of the right shape to feed into the keras model
        data = np.ndarray(shape=(1, 224, 224, 3), dtype=np.float32)

        # Replace this with the path to your image (escape backslashes)
        image_path = os.path.join(project_folder, "C1P4H1.jpg")
        image = Image.open(image_path).convert("RGB")

        # resizing the image to be at least 224x224 and then cropping from the center
        size = (224, 224)
        image = ImageOps.fit(image, size, Image.LANCZOS)

        # turn the image into a numpy array
        image_array = np.asarray(image)

        # Normalize the image
        normalized_image_array = (image_array.astype(np.float32) / 127.5) - 1

        # Load the image into the array
        data[0] = normalized_image_array

        # Predicts the model
        prediction = model.predict(data)
        index = np.argmax(prediction)
        class_name = class_names[index]
        confidence_score = prediction[0][index]

        # Display the class and confidence score
        self.class_label.config(text=f'Class: {class_name[2:]}')
        self.confidence_label.config(text=f'Confidence Score: {confidence_score}')

        # Display the image
        img = Image.open("C1P4H1.jpg")
        img = img.resize((128, 128), Image.LANCZOS)
        image = ImageTk.PhotoImage(img)
        self.imageLabel.configure(image=image)
        self.imageLabel.image = image

    def __init__(self):
        # Create the main window.
        self.main_window = tk.Tk()
        self.main_window.title("Capstone Classifier")
        self.main_window.geometry("400x400")  # Increased window height for displaying the image

        self.image_frame = tk.Frame(self.main_window)
        self.class_frame = tk.Frame(self.main_window)
        self.confidence_frame = tk.Frame(self.main_window)
        self.button_frame = tk.Frame(self.main_window)

        # Create labels
        self.class_label = tk.Label(self.class_frame, text='Class:')
        self.confidence_label = tk.Label(self.confidence_frame, text='Confidence Score:')
        self.imageLabel = tk.Label(self.image_frame)

        # Create a single button for both functions
        self.chili_button = tk.Button(self.button_frame, text="Classify Chili and Show Image", command=self.chili_classification)
        self.lemon_button = tk.Button(self.button_frame, text="Classify Lemon and Show Image", command=self.lemon_classification)
        self.coffee_button = tk.Button(self.button_frame, text="Classify Coffee and Show Image", command=self.coffee_classification)

        # Pack labels, button, and frames
        self.class_label.pack()
        self.confidence_label.pack()
        self.imageLabel.pack(side=tk.TOP)
        self.chili_button.pack(side=tk.TOP)
        self.lemon_button.pack(side=tk.TOP)
        self.coffee_button.pack(side=tk.TOP)

        self.class_frame.pack()
        self.confidence_frame.pack()
        self.image_frame.pack()
        self.button_frame.pack()

        # Start the GUI main loop
        self.main_window.mainloop()

# Create an instance of the Capstone_GUI class
capstone_gui = Capstone_GUI()
