from mobile import MobilePhone

# Creating a MobilePhone object
phone = MobilePhone("Acme Electronics", "M1000", "$199.99")
# Printing phone information
print("Phone Manufacturer:", phone.get_manufact())
print("Phone Model:", phone.get_model())
print("Retail Price:", phone.get_retail_price())

sense = True

while sense:
    y_n_input = input("Would you like to enter another phone? (y/n): ")

    if y_n_input == "y":
        manufact_update = input("\nEnter the manufacturer: ")
        model_update = input("Enter the model number: ")
        ret_price_update = input("Enter the retail price: ")
        # Modifying the phone attributes
        phone.set_manufact(manufact_update)
        phone.set_model(model_update)
        phone.set_retail_price(ret_price_update)

        # Printing modified phone information
        print("\nHere is the data that you entered:")
        print("Phone Manufacturer:", phone.get_manufact())
        print("Phone Model:", phone.get_model())
        print("Retail Price:", phone.get_retail_price())
    elif y_n_input == "n":
        sense = False
    else:
        print("Please only enter 'y' or 'n'.")