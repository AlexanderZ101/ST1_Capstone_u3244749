import tkinter as tk
from tkinter import messagebox

class WordReadWriteTool:
    def __init__(self, root):
        self.root = root
        self.root.title("Word List File Writer and Reader")
        self.root.geometry("600x500")

        self.num_of_words_entry_frame = tk.Frame()
        self.words_entry_frame = tk.Frame()
        self.results_top_frame = tk.Frame()
        self.results_bottom_frame = tk.Frame()

        self.num_of_words_label = tk.Label(self.num_of_words_entry_frame, text="Please enter the number of words you would like to write to the file:")
        self.num_of_words_entry = tk.Entry(self.num_of_words_entry_frame, bg="grey")
        self.begin_button = tk.Button(self.num_of_words_entry_frame, text="Begin", bg='grey', command=self.word_entry)

        self.num_of_words_entry_frame.pack()
        self.words_entry_frame.pack()
        self.results_top_frame.pack()
        self.results_bottom_frame.pack()
        self.num_of_words_label.pack(side="left")
        self.num_of_words_entry.pack(side="left")
        self.begin_button.pack(side="left")

        self.current_word = 1

    def word_entry(self):
        try:
            self.num_of_words = int(self.num_of_words_entry.get())
            if self.num_of_words <= 0:
                messagebox.showerror("Word number error", "Number of words cannot be 0")
                return

            self.num_of_words_label.destroy()
            self.num_of_words_entry.destroy()
            self.begin_button.destroy()

            self.instructions_label = tk.Label(self.words_entry_frame, text='Please enter a single word and click "Add Word"')
            self.words_entry_label = tk.Label(self.words_entry_frame, text=f"Enter word {self.current_word}:")
            self.words_entry = tk.Entry(self.words_entry_frame, bg="grey")

            self.word_add = tk.Button(self.words_entry_frame, text="Add Word", bg='grey', command=self.add_word)

            self.instructions_label.pack()
            self.words_entry_label.pack()
            self.words_entry.pack()
            self.word_add.pack()

        except ValueError:
            messagebox.showerror("Input Error", "Please enter a number for the number of words")

    def add_word(self):
        try:
            if self.current_word <= self.num_of_words:
                word = self.words_entry.get()
                with open("words.txt", "a") as file:
                    file.write(word + "\n")
                self.current_word += 1
                self.words_entry_label.config(text=f"Enter word {self.current_word}:")

            if self.current_word > self.num_of_words:
                self.display_results()
        except TypeError:
            messagebox.showerror("Input Error", "Please enter words only")

    def analyze_words_from_file(self):
        with open("words.txt", "r") as file:
            words = file.read().split()

        num_words = len(words)
        longest_word = max(words, key=len)
        total_length = sum(len(word) for word in words)
        average_length = total_length / num_words

        return num_words, longest_word, total_length, average_length

    def display_results(self):
        self.instructions_label.destroy()
        self.words_entry_label.destroy()
        self.words_entry.destroy()
        self.word_add.destroy()
        results_label = tk.Label(self.results_top_frame, text="Results:")
        num_of_words, longest_word, total_length, average_length = self.analyze_words_from_file()
        num_of_word_in_file = tk.Label(self.results_bottom_frame, text=f"Number of words: {num_of_words}")
        longest_word_in_file = tk.Label(self.results_bottom_frame, text=f"Longest word: {longest_word}")
        total_length_of_word_in_file = tk.Label(self.results_bottom_frame, text=f"Total leng of words in file: {total_length}")
        average_length_of_word_in_file = tk.Label(self.results_bottom_frame, text=f"Average Lenght of words in file:{average_length:.2f}")
        quit_button = tk.Button(self.results_bottom_frame, text="Quit", command=self.quit)

        results_label.pack()
        num_of_word_in_file.pack()
        longest_word_in_file.pack()
        total_length_of_word_in_file.pack()
        average_length_of_word_in_file.pack()
        quit_button.pack()

    def quit(self):
        with open("words.txt", "w") as file:
            pass
        self.root.quit()


if __name__ == "__main__":
    root = tk.Tk()
    word_list_reader_writer = WordReadWriteTool(root)
    root.mainloop()
