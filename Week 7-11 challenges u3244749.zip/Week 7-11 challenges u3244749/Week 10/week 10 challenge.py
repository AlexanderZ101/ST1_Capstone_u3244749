# PART 1
class LibraryItem:
    # constructor
    def __init__(self, name, author, publisher):
        # creating private data members
        self.item_name = name
        self.item_author = author
        self.item_publisher = publisher

    def getItemName(self):
        return self.item_name

    def getItemAuthor(self):
        return self.item_author

    def getItemPublisher(self):
        return self.item_publisher

    def setItemName(self, name):
        self.item_name = name

    def setItemAuthor(self, author):
        self.item_author = author

    def setItemPublisher(self, publisher):
        self.item_publisher = publisher

    def getNumOfPages(self):
        pass

    def getHardcopy(self):
        pass

    def getEbook(self):
        pass


# PART 2
class Book(LibraryItem):
    def __init__(self, name, author, publisher, num_of_pages, hardcopy, ebook):
        super().__init__(name, author, publisher)
        self.item_num_of_pages = num_of_pages
        self.item_hardcopy = hardcopy
        self.item_ebook = ebook

    def getNumOfPages(self):
        return self.item_num_of_pages

    def getHardcopy(self):
        return self.item_hardcopy

    def getEbook(self):
        return self.item_ebook

    def setNumOfPages(self, num_of_pages):
        self.item_num_of_pages = num_of_pages

    def setHardcopy(self, hardcopy):
        self.item_hardcopy = hardcopy

    def setEbook(self, ebook):
        self.item_ebook = ebook


# tester program

import tkinter as tk


class WordReadWriteTool:
    def __init__(self, root, book1):
        self.root = root
        self.root.title("Tester program GUI")
        self.root.geometry("600x500")

        self.text_frame = tk.Frame(self.root)  # Create a frame inside the root window.

        self.status_hardcopy = "Yes" if book1.getHardcopy() else "No"
        self.status_eBook = "Yes" if book1.getEbook() else "No"

        print(f"Book 1 eBook: {self.status_eBook}")

        self.tester_text = tk.Text(self.text_frame, bg="light blue", fg='red')
        self.tester_text.insert("1.0", f"==========================================\n"
                                       f"Book 1 Name: {book1.getItemName()}\n"
                                       f"Book 1 Author: {book1.getItemAuthor()}\n"
                                       f"Book 1 Publisher: {book1.getItemPublisher()}\n"
                                       f"Book 1 Number of pages: {book1.getNumOfPages()}\n"
                                       f"Book 1 Hardcopy: {self.status_hardcopy}\n"
                                       f"Book 1 eBook: {self.status_eBook}\n"
                                       f"==========================================")

        self.tester_text.pack()
        self.text_frame.pack()




if __name__ == "__main__":
    item1 = LibraryItem("Item 1", "Author 1", "Publisher 1")
    item2 = LibraryItem("Item 2", "Author 2", "Publisher 2")
    item3 = LibraryItem("Item 3", "Author 3", "Publisher 3")
    print("\nPart 1 tester program")
    print("==========================================")
    print(f"Item 1 Name: {item1.getItemName()}")
    print(f"Item 2 Author: {item2.getItemAuthor()}")
    print(f"Item 3 Publisher: {item3.getItemPublisher()}")
    print("==========================================\n")

    book1 = Book("Book 1", "Author 4", "Publisher 4", 700, True, False)

    print("Part 2 tester program")
    print("==========================================")
    print(f"Book 1 Name: {book1.getItemName()}")
    print(f"Book 1 Author: {book1.getItemAuthor()}")
    print(f"Book 1 Publisher: {book1.getItemPublisher()}")
    print(f"Book 1 Number of pages: {book1.getNumOfPages()}")

    if book1.getHardcopy() == True:
        status_hardcopy = str("Yes")
    else:
        status_hardcopy = str("No")

    print(f"Book 1 Hardcopy: {status_hardcopy}")

    if book1.getEbook() == True:
        status_eBook = str("Yes")
    else:
        status_eBook = str("No")

    print(f"Book 1 eBook: {status_eBook}")

    print("==========================================\n")
    root = tk.Tk()
    word_list_reader_writer = WordReadWriteTool(root, book1)
    root.mainloop()
